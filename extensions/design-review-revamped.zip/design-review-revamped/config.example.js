/**
 * Supabase sync (optional). Copy this file to config.js and fill in values
 * from Project Settings → API (Project URL and anon public key).
 *
 * If url or anonKey is empty, comments stay in chrome.storage.local only.
 */
var DESIGN_REVIEW_SUPABASE = {
  url: 'https://YOUR_PROJECT_REF.supabase.co',
  anonKey: 'YOUR_SUPABASE_ANON_KEY',
};
