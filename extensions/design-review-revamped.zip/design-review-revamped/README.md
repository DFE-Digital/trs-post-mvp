# Design review revamped (Supabase)

Chrome extension that adds numbered pins, threaded comments, and a per-thread **resolved** state for the page you are on. This variant adds **optional Supabase** sync so teams can share threads by URL.

- **Without Supabase:** data lives in `chrome.storage.local` on this browser only (same as the local `design-review` extension).
- **With Supabase:** the same `page_key` (origin + path + query) is shared in a table so reviewers on other machines or browsers see the same threads. The extension still mirrors a copy locally. While the comments panel is open, it polls about every 12 seconds for updates.

The original **local-only** extension is unchanged in `extensions/design-review`.

## Install (developer mode)

1. Open Chrome and go to `chrome://extensions`.
2. Turn on **Developer mode**.
3. Click **Load unpacked** and choose this folder: `extensions/design-review-revamped`.
4. After code changes, click **Reload** on the extension card.
5. Click the **puzzle piece** in the Chrome toolbar, find this extension, and click the **pin** so the icon stays visible (Chrome hides new extensions by default).

## Optional: Supabase setup

1. Create a project at [supabase.com](https://supabase.com).
2. In the dashboard, open **SQL** → **New query**, paste the contents of `supabase-schema.sql`, and run it.
3. Open **Project Settings** → **API** and copy the **Project URL** and **anon public** key.
4. Edit `config.js` (or copy `config.example.js` to `config.js`) and set `url` and `anonKey`.
5. Reload the extension on `chrome://extensions`.

**Security:** the sample RLS policies allow any client holding the anon key to read and write all rows. That is only suitable for trusted teams or prototypes. Before wider use, add authentication (Supabase Auth), a workspace or project id column, and policies that restrict `select` / `insert` / `update` / `delete` to authorised users.

**Keys:** do not commit real `anonKey` values to a public git repository. If the key is ever exposed, rotate it in the Supabase dashboard.

## Use

1. Open any website (including local prototypes).
2. Click the extension icon in the toolbar to open the **Comments on this page** panel (click again to close).
3. Click **Add pin to page**, then click the page where you want a pin. The crosshair turns off after one placement.
4. Use the **Review** floating button to turn placement mode on or off without opening the panel.
5. Click a pin to open its thread. Use **Reply** under a comment for nested replies. Use the check control to resolve a thread and grey out the pin.

## Limits (prototype)

- **Last write wins:** two people editing the same page at the same time can overwrite each other’s full thread list. Finer-grained APIs or realtime merge would be a follow-up.
- Pins use a generated CSS selector; if the DOM changes a lot, a pin may drift or fall back to the saved viewport position.
- **Page key** includes the query string, so different `?utm_…` values split threads. You can normalise that in code later if needed.
- Some restricted URLs (for example `chrome://`) cannot run content scripts.

## Cross-browser

The same pattern works in other Chromium browsers. Firefox needs manifest and API checks; you can introduce the `webextension-polyfill` if you standardise on `browser.*` APIs.
