/**
 * Optional Supabase sync. Replace with real values (see config.example.js).
 * Do not commit real keys to a public repository.
 */
var DESIGN_REVIEW_SUPABASE = {
  url: '',
  anonKey: '',
};
